﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetterServer.Data
{
    public class Vector2
    {
        public int X, Y;

        public Vector2() { }
        public Vector2(int x, int y) { X = x; Y = y; }
    }
}
