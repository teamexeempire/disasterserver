﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetterServer.Data
{
    public enum ExeCharacter
    {
        None = -1,
        Original,
        Chaos,
        Exetior,
        Exeller
    }
}
