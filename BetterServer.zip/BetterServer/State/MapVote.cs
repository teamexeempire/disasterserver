﻿using BetterServer.Data;
using BetterServer.Maps;
using BetterServer.Session;
using ExeNet;
using System.Net;

namespace BetterServer.State
{
    class MapVoteMap
    {
        public Map Map;
        public byte MapID;
        public int Votes;
    }

    public class MapVote : State
    {
        /* List of possible maps */
        public static readonly Type[] Maps = new Type[]
        {
            typeof(HideAndSeek2),
            typeof(RavineMist),
            typeof(DotDotDot),
            typeof(DesertTown),
            typeof(YouCantRun),
            typeof(LimpCity),
            typeof(NotPerfect),
            typeof(KindAndFair),
            typeof(Act9),
            typeof(NastyParadise),
            typeof(PricelessFreedom),
            typeof(VolcanoValley),
            typeof(GreenHill),
            typeof(MajinForest),
            typeof(AngelIsland)
        };

        private MapVoteMap[] _votes = new MapVoteMap[]
        {
            new(),
            new(),
            new(),
        };

        private int _timer = Ext.FRAMESPSEC;
        private int _timerSec = 30;
        private Random _rand = new();
        private Dictionary<ushort, bool> _votePeers = new();

        public override Session.State AsState()
        {
            return Session.State.VOTE;
        }

        public override void Init(Session.Server server)
        {
            var numbers = new List<int>();
            var number = _rand.Next(0, Maps.Length);

            for (var i = 0; i < _votes.Length; i++)
            {
                while (numbers.Contains(number))
                    number = _rand.Next(0, Maps.Length);

                numbers.Add(number);
            }

            for (var i = 0; i < numbers.Count; i++)
            {
                //_votes[i].Map = Ext.CreateOfType<Act9>(); //Democracy 
                //_votes[i].MapID = (byte)Array.IndexOf(Maps, typeof(Act9));
                _votes[i].Map = Ext.CreateOfType<Map>(Maps[numbers[i]]);
                _votes[i].MapID = (byte)numbers[i];
                _votes[i].Votes = 0;
            }

            lock (server.Peers)
            {
                foreach (var peer in server.Peers)
                    _votePeers.Add(peer.Key, false);
            }

            var packet = new TcpPacket(PacketType.SERVER_VOTE_MAPS, _votes[0].MapID, _votes[1].MapID, _votes[2].MapID);
            server.TCPMulticast(packet);
        }

        public override void PeerJoined(Session.Server server, TcpSession session, Peer peer)
        {
        }

        public override void PeerLeft(Session.Server server, TcpSession session, Peer peer)
        {
            lock (server.Peers)
            {
                if (server.Peers.Count <= 1)
                {
                    server.SetState<Lobby>();
                    return;
                }

                lock (_votePeers)
                {
                    _votePeers.Remove(session.ID);

                    if (_votePeers.Count(e => !e.Value) <= 0)
                        CheckVotes(server);
                }
            }
        }

        public override void PeerTCPMessage(Session.Server server, TcpSession session, BinaryReader reader)
        {
            var passtrough = reader.ReadBoolean();
            var type = reader.ReadByte();

            if (passtrough)
                server.Passtrough(reader, session);

            switch ((PacketType)type)
            {
                case PacketType.CLIENT_VOTE_REQUEST:
                    {
                        var map = reader.ReadByte();

                        if (map >= _votes.Length)
                            break;

                        if (_votePeers[session.ID])
                            break;

                        lock (_votePeers)
                        {
                            _votePeers[session.ID] = true;

                            if (_votePeers.Count(e => !e.Value) <= 0)
                            {
                                if (_timerSec > 3)
                                {
                                    _timer = 1;
                                    _timerSec = 4;
                                }
                            }
                        }

                        _votes[map].Votes++;

                        var pkt = new TcpPacket(PacketType.SERVER_VOTE_SET, (byte)_votes[0].Votes, (byte)_votes[1].Votes, (byte)_votes[2].Votes);
                        server.TCPMulticast(pkt);
                        break;
                    }
            }
        }

        public override void PeerUDPMessage(Server server, IPEndPoint IPEndPoint, BinaryReader reader)
        {
        }

        public override void Tick(Server server)
        {
            if (_timer-- <= 0)
            {
                _timer = Ext.FRAMESPSEC;
                _timerSec--;

                var packet = new TcpPacket(PacketType.SERVER_VOTE_TIME_SYNC, (byte)_timerSec);
                server.TCPMulticast(packet);

                if (_timerSec <= 0)
                    CheckVotes(server);
            }
        }

        private void CheckVotes(Server server)
        {
            var max = _votes.Max(e => e.Votes);
            var votes = _votes.Where(e => e.Votes == max).ToArray();
            var map = votes[_rand.Next(0, votes.Length)];

            lock (server.Peers)
            {
                foreach (var peer in server.Peers.Values)
                {
                    if (peer.Player.Character != Character.EXE)
                        peer.ExeChance += _rand.Next(4, 10);
                    else
                        peer.ExeChance += _rand.Next(0, 2);
                }
            }

            server.SetState(new CharacterSelect(map.Map));
        }
    }
}
