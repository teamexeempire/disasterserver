# ExeNet
ExeNet is a library used for TCP/UDP communication.
Don't use it please its really bad

# License 
Whole thing licensed under GPL.
